package com.company.model.Repository;

import com.company.model.entitiies.Flight;

public interface InterfaceUserRepository {

    // interface for userRepository

    void registerNewTicket(Flight newFlight);

}
